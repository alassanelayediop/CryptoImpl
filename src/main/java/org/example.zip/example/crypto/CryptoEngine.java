package org.example.crypto;

import java.io.File;

public interface CryptoEngine<K> {
    K generateKey(int keySize) throws Exception;

    String encrypt(K key, String plainText) throws Exception;

    String decrypt(K key, String cipherText) throws Exception;

    void saveKey(K key, File file) throws Exception;

    K loadKey(File file) throws Exception;
}
