package org.example.crypto.rsa;

import org.example.crypto.CryptoEngine;

import javax.crypto.Cipher;
import java.io.File;
import java.nio.file.Files;
import java.security.*;
import java.security.spec.*;
import java.util.Base64;

public class RsaCryptoEngine implements CryptoEngine<KeyPair> {

    private static final String TRANSFORMATION = "RSA/ECB/PKCS1Padding";

    @Override
    public KeyPair generateKey(int keySize) throws Exception {
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(keySize);
        return gen.generateKeyPair();
    }

    @Override
    public String encrypt(KeyPair key, String plainText) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, key.getPublic());
        return Base64.getEncoder().encodeToString(cipher.doFinal(plainText.getBytes()));
    }

    @Override
    public String decrypt(KeyPair key, String cipherText) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, key.getPrivate());
        return new String(cipher.doFinal(Base64.getDecoder().decode(cipherText)));
    }

    @Override
    public void saveKey(KeyPair key, File file) throws Exception {
        String content =
                "PUBLIC_KEY:\n" +
                        Base64.getEncoder().encodeToString(key.getPublic().getEncoded()) +
                        "\nPRIVATE_KEY:\n" +
                        Base64.getEncoder().encodeToString(key.getPrivate().getEncoded());

        Files.writeString(file.toPath(), content);
        file.setWritable(false);
    }

    @Override
    public KeyPair loadKey(File file) throws Exception {
        String[] parts = Files.readString(file.toPath()).split("PRIVATE_KEY:\n");

        byte[] pubBytes = Base64.getDecoder()
                .decode(parts[0].replace("PUBLIC_KEY:\n", "").trim());
        byte[] privBytes = Base64.getDecoder()
                .decode(parts[1].trim());

        KeyFactory kf = KeyFactory.getInstance("RSA");
        PublicKey pub = kf.generatePublic(new X509EncodedKeySpec(pubBytes));
        PrivateKey priv = kf.generatePrivate(new PKCS8EncodedKeySpec(privBytes));

        return new KeyPair(pub, priv);
    }
}