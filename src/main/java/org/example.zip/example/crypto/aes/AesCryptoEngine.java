package org.example.crypto.aes;

import org.example.crypto.CryptoEngine;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.nio.file.Files;
import java.util.Base64;

public class AesCryptoEngine implements CryptoEngine<SecretKey> {

    private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";

    @Override
    public SecretKey generateKey(int keySize) throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(keySize);
        return keyGen.generateKey();
    }

    @Override
    public String encrypt(SecretKey key, String plainText) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return Base64.getEncoder().encodeToString(cipher.doFinal(plainText.getBytes()));
    }

    @Override
    public String decrypt(SecretKey key, String cipherText) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, key);
        return new String(cipher.doFinal(Base64.getDecoder().decode(cipherText)));
    }

    @Override
    public void saveKey(SecretKey key, File file) throws Exception {
        Files.writeString(file.toPath(),
                Base64.getEncoder().encodeToString(key.getEncoded()));
        file.setWritable(false);
    }

    @Override
    public SecretKey loadKey(File file) throws Exception {
        byte[] decoded = Base64.getDecoder().decode(Files.readString(file.toPath()));
        return new SecretKeySpec(decoded, "AES");
    }
}
