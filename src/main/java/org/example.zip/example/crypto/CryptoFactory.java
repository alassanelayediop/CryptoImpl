package org.example.crypto;

import org.example.CryptoType;
import org.example.crypto.aes.AesCryptoEngine;
import org.example.crypto.rsa.RsaCryptoEngine;

public class CryptoFactory {

    public static CryptoEngine<?> create(CryptoType type) {
        if (type == null) {
            throw new IllegalArgumentException("CryptoType null — ComboBox non initialisée");
        }

        return switch (type) {
            case AES -> new AesCryptoEngine();
            case RSA -> new RsaCryptoEngine();
        };
    }
}
