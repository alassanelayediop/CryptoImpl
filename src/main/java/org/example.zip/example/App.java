package org.example;

import org.example.RSA.CryptoImplRSA;
import org.example.crypto.*;
import org.example.AES.CryptoImplAES;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.crypto.BadPaddingException;
import javax.crypto.SecretKey;
import java.io.File;
import java.security.KeyPair;
import java.util.Base64;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class App extends Application {

    CryptoImplAES cryptoAES = new CryptoImplAES();
    CryptoImplRSA cryptoRSA = new CryptoImplRSA();
    private SecretKey loadedKey;

    private TextArea taPlain;
    private TextArea taCipher;
    private TextField tfKey;
    private TextField tfAESKey;
    TextArea taPublicKey;
    TextArea taPrivateKey;

    private RadioButton rbEncrypt;
    private RadioButton rbDecrypt;

    private ComboBox<CryptoType> cbCryptoType;
    private ComboBox<KeySize> cbKeySize;

    private CryptoEngine<?> engine;
    private Object currentKey;

    private SecretKey aesKey;
    private KeyPair rsaKeyPair;

    @Override
    public void start(Stage stage) {

        tfKey = new TextField();
        tfKey.setPromptText("Clé AES (Base64)");
        tfKey.setEditable(false);

        cbCryptoType = new ComboBox<>();
        cbCryptoType.setItems(FXCollections.observableArrayList(CryptoType.values()));
        cbCryptoType.setValue(CryptoType.AES);
        // cbCryptoType.setItems(FXCollections.observableArrayList(CryptoType.values()));
        // cbCryptoType.setValue(CryptoType.AES);

        cbKeySize = new ComboBox<>();

        cbCryptoType.setOnAction(e -> {
            CryptoType type = cbCryptoType.getValue();

            engine = CryptoFactory.create(cbCryptoType.getValue());
            currentKey = null;
            tfKey.clear();

            ObservableList<KeySize> sizes = FXCollections.observableArrayList();
            for (KeySize ks : KeySize.values()) {
                if (ks.getType() == type) {
                    sizes.add(ks);
                }
            }

            cbKeySize.setItems(sizes);
            cbKeySize.setValue(sizes.get(0));
        });

        taPlain = new TextArea();
        taPlain.setPromptText("Texte clair à chiffrer...");

        taCipher = new TextArea();
        taCipher.setPromptText("Texte chiffré...");

        Button btnGenKey = new Button("Générer Clé");
        Button btnLoadKey = new Button("Charger une clé");
        Button btnSaveKey = new Button("Sauvegarder la clé");

        Button btnLoadText = new Button("Importer");
        Button btnProcess = new Button("Exécuter");
        Button btnSaveOutput = new Button("Sauvegarder le résultat");

        Button btnQuit = new Button("Quitter");

        rbEncrypt = new RadioButton("Chiffrer");
        rbDecrypt = new RadioButton("Déchiffrer");
        rbEncrypt.setSelected(true);

        ToggleGroup group = new ToggleGroup();
        rbEncrypt.setToggleGroup(group);
        rbDecrypt.setToggleGroup(group);

        rbEncrypt.setOnAction(e -> {
            taPlain.setPromptText("Texte clair à chiffrer...");
            taCipher.setPromptText("Résultat du chiffrement...");
            btnProcess.setText("Chiffrer");
            taPlain.setText("");
            taCipher.setText("");
        });

        rbDecrypt.setOnAction(e -> {
            taPlain.setPromptText("Texte chiffré à déchiffrer...");
            taCipher.setPromptText("Texte déchiffré...");
            btnProcess.setText("Déchiffrer");
            taPlain.setText("");
            taCipher.setText("");
        });

        btnGenKey.setOnAction(e -> {
            try {
                CryptoType type = cbCryptoType.getValue();
                KeySize size = cbKeySize.getValue();

                engine = CryptoFactory.create(type);

                currentKey = engine.generateKey(size.getSize());

                if (type == CryptoType.AES) {
                    SecretKey k = (SecretKey) currentKey;
                    tfKey.setText(Base64.getEncoder().encodeToString(k.getEncoded()));
                } else {
                    KeyPair kp = (KeyPair) currentKey;
                    taPublicKey.setText(
                            Base64.getEncoder().encodeToString(kp.getPublic().getEncoded())
                    );
                    taPrivateKey.setText(
                            Base64.getEncoder().encodeToString(kp.getPrivate().getEncoded())
                    );
                }

            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });


        btnLoadKey.setOnAction(e -> {
            try {
                FileChooser fc = createTxtChooser("Charger une clé AES", null);
                File f = fc.showOpenDialog(stage);

                if (f != null) {
                    SecretKey key = cryptoAES.loadKey(f);
                    loadedKey = key;
                    tfKey.setText(Base64.getEncoder().encodeToString(key.getEncoded()));
                }
            } catch (Exception ex) { alert("Erreur", ex.getMessage()); }
        });

        btnSaveKey.setOnAction(e -> {
            try {
                if (loadedKey == null) { error("Aucune clé chargée ou générée."); return; }

                FileChooser fc = createTxtChooser("Sauvegarder la clé AES", "key");
                File f = ensureTxtExtension(fc.showSaveDialog(stage));

                if (f != null) {
                    cryptoAES.saveKey(loadedKey, f);
                    info("Succès", "Clé sauvegardée avec succès !");
                }
            } catch (Exception ex) { alert("Erreur", ex.getMessage()); }
        });

        btnLoadText.setOnAction(e -> {
            try {
                FileChooser fc = createTxtChooser("Importer un texte", null);
                File f = fc.showOpenDialog(stage);

                if (f != null) {
                    taPlain.setText(cryptoAES.loadText(f));
                }
            } catch (Exception ex) { alert("Erreur", ex.getMessage()); }
        });

        String transformation = "AES/ECB/PKCS5Padding";
        btnProcess.setOnAction(e -> {
            try {
                if (engine == null || currentKey == null) {
                    error("Générez ou chargez une clé");
                    return;
                }

                if (taPlain.getText().isBlank()) {
                    error("Texte vide");
                    return;
                }

                String result = rbEncrypt.isSelected()
                        ? encrypt()
                        : decrypt();

                taCipher.setText(result);

            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnSaveOutput.setOnAction(e -> {
            try {
                FileChooser fc = createTxtChooser("Sauvegarder le résultat",
                        rbEncrypt.isSelected() ? "ciphertext" : "plaintext");

                File f = ensureTxtExtension(fc.showSaveDialog(stage));

                if (f != null) {
                    cryptoAES.saveCiphertext(taCipher.getText(), f);
                    info("Succès", "Message sauvegardé avec succès !");
                }
            } catch (Exception ex) { alert("Erreur", ex.getMessage()); }
        });

        btnQuit.setOnAction(event -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText("Voulez-vous vraiment quitter l'application ?");
            alert.setContentText("Toutes les données non sauvegardées seront perdues.");

            ButtonType btnOui = new ButtonType("Oui", ButtonBar.ButtonData.OK_DONE);
            ButtonType btnNon = new ButtonType("Non", ButtonBar.ButtonData.CANCEL_CLOSE);

            alert.getButtonTypes().setAll(btnOui, btnNon);

            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == btnOui) {
                stage.close();
            } else {
                event.consume();
            }
        });

        HBox modeBox = new HBox(15, rbEncrypt, rbDecrypt);
        modeBox.setAlignment(Pos.CENTER);

        HBox keyButtons = new HBox(10, btnGenKey, btnLoadKey, btnSaveKey);
        keyButtons.setAlignment(Pos.CENTER);

        HBox processButtons = new HBox(10, btnProcess, btnSaveOutput);
        processButtons.setAlignment(Pos.CENTER);

        HBox cryptoConfigBox = new HBox(15);
        cryptoConfigBox.setAlignment(Pos.CENTER);

        Label lblType = new Label("Type :");
        Label lblSize = new Label("Taille :");

        cryptoConfigBox.getChildren().addAll(
                lblType, cbCryptoType,
                lblSize, cbKeySize
        );

        VBox root = new VBox(15,
                // new Label("Clé AES :"), tfKey, keyButtons,
                cryptoConfigBox,

                new Label("Clé :"),
                tfKey,
                keyButtons,

                new Separator(),

                new Label("Mode :"),
                modeBox,

                new Label("Entrée :"),
                taPlain,
                btnLoadText,

                new Label("Sortie :"),
                taCipher,
                processButtons,

                new Separator(),
                btnQuit
        );

        root.setPadding(new Insets(15));

        Scene scene = new Scene(root, 650, 750);
        scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/styles.css")).toExternalForm());

        stage.setTitle("TP AES - Chiffrement & Déchiffrement");
        stage.setScene(scene);
        stage.show();
    }

    private void alert(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle(title);
        a.setContentText(msg);
        a.show();
    }

    private void info(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setHeaderText(title);
        a.setContentText(msg);
        a.showAndWait();
    }

    private FileChooser createTxtChooser(String title, String defaultName) {
        FileChooser fc = new FileChooser();
        fc.setTitle(title);
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers texte (*.txt)", "*.txt"));

        if (defaultName != null) {
            fc.setInitialFileName(defaultName + ".txt");
        }
        return fc;
    }

    private File ensureTxtExtension(File file) {
        if (file != null && !file.getName().toLowerCase().endsWith(".txt")) {
            return new File(file.getAbsolutePath() + ".txt");
        }
        return file;
    }

    private void error(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText("Erreur détectée");
        alert.setContentText(message);
        alert.showAndWait();
    }

    @SuppressWarnings("unchecked")
    private String encrypt() throws Exception {
        return ((CryptoEngine<Object>) engine)
                .encrypt(currentKey, taPlain.getText());
    }

    @SuppressWarnings("unchecked")
    private String decrypt() throws Exception {
        return ((CryptoEngine<Object>) engine)
                .decrypt(currentKey, taPlain.getText());
    }

//    private String encrypt() throws Exception {
//        return engine.encrypt(currentKey, taPlain.getText());
//    }
//
//    private String decrypt() throws Exception {
//        return engine.decrypt(currentKey, taPlain.getText());
//    }

    public static void main(String[] args) {
        launch(args);
    }
}