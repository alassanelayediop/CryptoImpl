package org.example.AES;

import javax.crypto.*;
import java.io.File;
import java.security.NoSuchAlgorithmException;

public interface Icrypto
{
    SecretKey genKey(String algo, int keySize) throws NoSuchAlgorithmException;
    String encrypt(SecretKey key, String plainText, String transformation) throws Exception;
    String decrypt(SecretKey key, String cipherText, String transformation) throws Exception;
    void saveKey(SecretKey key, File file) throws Exception;
    void saveCiphertext(String cipherText, File file) throws Exception;
    SecretKey loadKey(File file) throws Exception;
    String loadText(File file) throws Exception;
}