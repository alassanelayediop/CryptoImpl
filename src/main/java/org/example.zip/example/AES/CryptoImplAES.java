package org.example.AES;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.file.Files;
import java.security.*;
import java.util.Base64;

public class CryptoImplAES implements Icrypto
{
    @Override
    public SecretKey genKey(String algo, int keySize) throws NoSuchAlgorithmException
    {
        KeyGenerator keyGen = KeyGenerator.getInstance(algo);
        keyGen.init(keySize);
        return keyGen.generateKey();
    }

    @Override
    public String encrypt(SecretKey key, String plainText, String transformation) throws Exception {
        Cipher c = Cipher.getInstance(transformation);
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] cipherText = c.doFinal(plainText.getBytes());

        return Base64.getEncoder().encodeToString(cipherText);
    }

    @Override
    public String decrypt(SecretKey key, String cipherText, String transformation) throws Exception {
        Cipher c = Cipher.getInstance(transformation);
        c.init(Cipher.DECRYPT_MODE, key);
        byte[] cipherTextDecode = Base64.getDecoder().decode(cipherText);
        byte[] plainText = c.doFinal(cipherTextDecode);
        return new String(plainText);
    }

    @Override
    public void saveKey(SecretKey key, File file) throws Exception {
       if(file == null){
           throw new FileNotFoundException("Aucun fichier fourni");
       }

       String encodedKey = Base64.getEncoder().encodeToString(key.getEncoded());
       Files.writeString(file.toPath(), encodedKey);
       // file.setWritable(false);
    }

    @Override
    public void saveCiphertext(String cipherText, File file) throws Exception {
        if(file == null){
            throw new FileNotFoundException("Aucun fichier fourni");
        }
        if (cipherText == null || cipherText.isEmpty()) {
            throw new IllegalArgumentException("Le texte chiffré est vide.");
        }

        Files.writeString(file.toPath(), cipherText);
        // file.setWritable(false);
    }

    @Override
    public SecretKey loadKey(File file) throws Exception {
        if (file == null || !file.exists()) {
            throw new FileNotFoundException("Le fichier spécifié est introuvable.");
        }

        String encodedKey = Files.readString(file.toPath());

        byte[] decodedKey = Base64.getDecoder().decode(encodedKey);

        if (decodedKey.length != 16) {
            throw new IllegalArgumentException("Clé invalide : elle doit faire 128 bits.");
        }

        return new SecretKeySpec(decodedKey, "AES");
    }

    @Override
    public String loadText(File file) throws Exception {
        if (file == null || !file.exists()) {
            throw new FileNotFoundException("Le fichier spécifié est introuvable.");
        }

        return Files.readString(file.toPath());
    }
}