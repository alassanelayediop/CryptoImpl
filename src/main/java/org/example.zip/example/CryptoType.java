package org.example;

public enum CryptoType {
    AES,
    RSA
}