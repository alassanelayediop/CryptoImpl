package org.example;

public enum KeySize {
    // AES
    AES_128(128, CryptoType.AES),
    AES_192(192, CryptoType.AES),
    AES_256(256, CryptoType.AES),

    // RSA
    RSA_1024(1024, CryptoType.RSA),
    RSA_2048(2048, CryptoType.RSA),
    RSA_4096(4096, CryptoType.RSA);

    private final int size;
    private final CryptoType type;

    KeySize(int size, CryptoType type) {
        this.size = size;
        this.type = type;
    }

    public int getSize() {
        return size;
    }

    public CryptoType getType() {
        return type;
    }

    @Override
    public String toString() {
        return size + " bits";
    }
}