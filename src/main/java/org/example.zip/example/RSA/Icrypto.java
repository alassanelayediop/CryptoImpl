package org.example.RSA;

import javax.crypto.SecretKey;
import java.io.File;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;

public interface Icrypto {
    KeyPair genKey(String algo, int keySize) throws NoSuchAlgorithmException;
    String encrypt(KeyPair key, String plainText, String transformation) throws Exception;
    String decrypt(KeyPair key, String cipherText, String transformation) throws Exception;
    void saveKey(KeyPair key, File file) throws Exception;
    void saveCiphertext(String cipherText, File file) throws Exception;
    KeyPair loadKey(File file) throws Exception;
    String loadText(File file) throws Exception;
}
