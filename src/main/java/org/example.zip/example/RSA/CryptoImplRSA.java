package org.example.RSA;

import javax.crypto.Cipher;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class CryptoImplRSA implements Icrypto
{
    @Override
    public KeyPair genKey(String algo, int keySize) throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance(algo);
        keyGen.initialize(keySize);
        return keyGen.generateKeyPair();
    }

    @Override
    public String encrypt(KeyPair key, String plainText, String transformation) throws Exception {
        PublicKey publicKey = key.getPublic();
        Cipher cipher = Cipher.getInstance(transformation);
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);

        byte[] cipherText = cipher.doFinal(plainText.getBytes());
        return Base64.getEncoder().encodeToString(cipherText);
    }

    @Override
    public String decrypt(KeyPair key, String cipherText, String transformation) throws Exception {
        PrivateKey privateKey = key.getPrivate();
        Cipher decipher = Cipher.getInstance(transformation);
        decipher.init(Cipher.DECRYPT_MODE, privateKey);

        byte[] cipherTextDecode = Base64.getDecoder().decode(cipherText);
        byte[] plainText = decipher.doFinal(cipherTextDecode);
        return new String(plainText);
    }

    @Override
    public void saveKey(KeyPair key, File file) throws Exception {
        if (file == null) {
            throw new FileNotFoundException("Aucun fichier fourni");
        }

        String publicKey = Base64.getEncoder().encodeToString(key.getPublic().getEncoded());
        String privateKey = Base64.getEncoder().encodeToString(key.getPrivate().getEncoded());

        String content =
                "-----BEGIN RSA PUBLIC KEY-----\n" +
                        publicKey + "\n" +
                        "-----END RSA PUBLIC KEY-----\n\n" +
                        "-----BEGIN RSA PRIVATE KEY-----\n" +
                        privateKey + "\n" +
                        "-----END RSA PRIVATE KEY-----";

        Files.writeString(file.toPath(), content);
    }

    @Override
    public void saveCiphertext(String cipherText, File file) throws Exception {
        if(file == null){
            throw new FileNotFoundException("Aucun fichier fourni");
        }
        if (cipherText == null || cipherText.isEmpty()) {
            throw new IllegalArgumentException("Le texte chiffré est vide.");
        }

        Files.writeString(file.toPath(), cipherText);
    }

    @Override
    public KeyPair loadKey(File file) throws Exception {
        if (file == null || !file.exists()) {
            throw new FileNotFoundException("Le fichier de clé est introuvable.");
        }

        String content = Files.readString(file.toPath());

        String publicKeyBase64 = content
                .split("-----BEGIN RSA PUBLIC KEY-----")[1]
                .split("-----END RSA PUBLIC KEY-----")[0]
                .trim();

        String privateKeyBase64 = content
                .split("-----BEGIN RSA PRIVATE KEY-----")[1]
                .split("-----END RSA PRIVATE KEY-----")[0]
                .trim();

        byte[] pubBytes = Base64.getDecoder().decode(publicKeyBase64);
        byte[] privBytes = Base64.getDecoder().decode(privateKeyBase64);

        KeyFactory keyFactory = KeyFactory.getInstance("RSA");

        PublicKey publicKey = keyFactory.generatePublic(new X509EncodedKeySpec(pubBytes));
        PrivateKey privateKey = keyFactory.generatePrivate(new PKCS8EncodedKeySpec(privBytes));

        return new KeyPair(publicKey, privateKey);
    }

    @Override
    public String loadText(File file) throws Exception {
        if (file == null || !file.exists()) {
            throw new FileNotFoundException("Le fichier spécifié est introuvable.");
        }

        return Files.readString(file.toPath());
    }
}